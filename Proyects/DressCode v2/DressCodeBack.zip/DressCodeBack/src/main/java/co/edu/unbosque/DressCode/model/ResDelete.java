package co.edu.unbosque.DressCode.model;

public class ResDelete {
	private int id;
	private String str;
	
	public ResDelete() {
		// TODO Auto-generated constructor stub
	}
	
	public ResDelete(int id, String str) {
		super();
		this.id = id;
		this.str = str;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStr() {
		return str;
	}

	public void setStr(String str) {
		this.str = str;
	}
}
