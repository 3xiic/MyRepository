package co.edu.unbosque.DressCode.repository;

import org.springframework.data.repository.CrudRepository;

import co.edu.unbosque.DressCode.model.PurchaseDetail;

public interface PurchaseDetailRepository extends CrudRepository<PurchaseDetail, Integer>{

}
