package co.edu.unbosque.DressCode.repository;

import org.springframework.data.repository.CrudRepository;

import co.edu.unbosque.DressCode.model.Amortization;

public interface AmortizationRepository extends CrudRepository<Amortization, Integer>{

}
