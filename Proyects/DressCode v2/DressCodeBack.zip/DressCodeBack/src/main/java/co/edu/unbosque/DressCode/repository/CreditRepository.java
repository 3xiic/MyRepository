package co.edu.unbosque.DressCode.repository;

import org.springframework.data.repository.CrudRepository;

import co.edu.unbosque.DressCode.model.Credit;

public interface CreditRepository extends CrudRepository<Credit, Integer>{

}
