package co.edu.unbosque.DressCode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DressCodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DressCodeApplication.class, args);
	}

}
